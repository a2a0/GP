package com.example.gb1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Contact extends AppCompatActivity {


    ImageView logo6;
    Button twitter,email;
    BottomNavigationView bnv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        logo6 = findViewById(R.id.imageView11);
        twitter = findViewById(R.id.buttonT);
        email = findViewById(R.id.buttonE);
        bnv = findViewById(R.id.navigation);

        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        twitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        bnv.setSelectedItemId(R.id.aboutpage);
        bnv.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.homepage:
                        startActivity(new Intent(getApplicationContext(),Scan.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.awarensspage:
                        startActivity(new Intent(getApplicationContext(),Source.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.rescanpage:
                        startActivity(new Intent(getApplicationContext(),Rescan.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.aboutpage:
                        return true;

                }
                return false;
            }
        });

    }
}
