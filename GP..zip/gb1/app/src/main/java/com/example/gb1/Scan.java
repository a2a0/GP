package com.example.gb1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Scan extends AppCompatActivity {

ImageView logo2;
Button scan;
BottomNavigationView bnv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);
         scan= findViewById(R.id.agreeto);
         logo2 = findViewById(R.id.imageView3);
         bnv = findViewById(R.id.navigation);

         scan.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {



                 Intent intent2= new Intent(Scan.this,Result.class);
                 startActivity(intent2);

             }
         });

         bnv.setSelectedItemId(R.id.homepage);
         bnv.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
             @Override
             public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                 switch (item.getItemId()){
                     case R.id.homepage:
                         return true;
                     case R.id.awarensspage:
                         startActivity(new Intent(getApplicationContext(),Source.class));
                         overridePendingTransition(0,0);
                         return true;
                     case R.id.rescanpage:
                         startActivity(new Intent(getApplicationContext(),Rescan.class));
                         overridePendingTransition(0,0);
                         return true;
                     case R.id.aboutpage:
                         startActivity(new Intent(getApplicationContext(),Contact.class));
                         overridePendingTransition(0,0);
                         return true;

                 }
                 return false;
             }
         });


    }
}