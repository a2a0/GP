package com.example.gb1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.content.Intent;

import com.google.android.material.bottomnavigation.BottomNavigationView;


public class Rescan extends AppCompatActivity {

    Button device, app, web, privacy, password;
    ImageView logo5;
    BottomNavigationView bnv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rescan);
        logo5 = findViewById(R.id.imageView9);
        device = findViewById(R.id.devicebutton);
        app = findViewById(R.id.appbutton);
        web = findViewById(R.id.webbutton);
        privacy = findViewById(R.id.privacybutton);
        password = findViewById(R.id.passwordbutton);
        bnv = findViewById(R.id.navigation);

        device.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent2= new Intent(Rescan.this,Result.class);
                startActivity(intent2);

            }
        });

        app.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2= new Intent(Rescan.this,Result.class);
                startActivity(intent2);

            }
        });

        web.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2= new Intent(Rescan.this,Result.class);
                startActivity(intent2);

            }
        });

        privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2= new Intent(Rescan.this,Result.class);
                startActivity(intent2);

            }
        });

        password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2= new Intent(Rescan.this,Result.class);
                startActivity(intent2);
            }
        });


        bnv.setSelectedItemId(R.id.rescanpage);
        bnv.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.homepage:
                        startActivity(new Intent(getApplicationContext(),Scan.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.awarensspage:
                        startActivity(new Intent(getApplicationContext(),Source.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.rescanpage:
                        return true;
                    case R.id.aboutpage:
                        startActivity(new Intent(getApplicationContext(),Contact.class));
                        overridePendingTransition(0,0);
                        return true;

                }
                return false;
            }
        });

    }}
