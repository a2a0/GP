package com.example.gb1;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

ImageView logo;
TextView agreement;
Button agree;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        logo = findViewById(R.id.imageView);
        agreement = findViewById(R.id.text1);
        agree = findViewById(R.id.agreeto);


        agree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(MainActivity.this, Scan.class);
                startActivity(intent1);
            }
        });
    }
    }

