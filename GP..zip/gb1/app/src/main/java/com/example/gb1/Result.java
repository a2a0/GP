package com.example.gb1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.content.Intent;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Result extends AppCompatActivity {


    ImageView logo3;
    Button beaware ;
    BottomNavigationView bnv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        logo3 = findViewById(R.id.imageView5);
        beaware = findViewById(R.id.aware);
        bnv = findViewById(R.id.navigation);


        beaware.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent3 = new Intent(Result.this,Source.class);
                startActivity(intent3);

            }
        });

        bnv.setSelectedItemId(R.id.homepage);
        bnv.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.homepage:
                        return true;
                    case R.id.awarensspage:
                        startActivity(new Intent(getApplicationContext(),Source.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.rescanpage:
                        startActivity(new Intent(getApplicationContext(),Rescan.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.aboutpage:
                        startActivity(new Intent(getApplicationContext(),Contact.class));
                        overridePendingTransition(0,0);
                        return true;

                }
                return false;
            }
        });

    }}