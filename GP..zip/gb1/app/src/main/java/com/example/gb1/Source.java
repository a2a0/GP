package com.example.gb1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Source extends AppCompatActivity {


    ImageView logo4;
    Button I, V, L, N;
    BottomNavigationView bnv;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_source);
        logo4 = findViewById(R.id.imageView7);
        I = findViewById(R.id.image);
        V = findViewById(R.id.vid);
        L = findViewById(R.id.link);
        N = findViewById(R.id.note);
        bnv = findViewById(R.id.navigation);

        I.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


            }
        });

        V.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        L.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        N.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        bnv.setSelectedItemId(R.id.awarensspage);
        bnv.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.homepage:
                        startActivity(new Intent(getApplicationContext(),Scan.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.awarensspage:
                        return true;
                    case R.id.rescanpage:
                        startActivity(new Intent(getApplicationContext(),Rescan.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.aboutpage:
                        startActivity(new Intent(getApplicationContext(),Contact.class));
                        overridePendingTransition(0,0);
                        return true;

                }
                return false;
            }
        });


















    }
}